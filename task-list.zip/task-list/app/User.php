<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

use Auth;
use App\Role;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'username',
        'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function role() {
        return $this->hasMany('App\UserRole','user_id', 'id');
    }

    public function tasks() {
        return $this->hasMany('App\UserTask', 'user_id', 'id')
            ->orderBy('created_at', 'desc');
    }

    public function roleDescription() {
        $user = Auth::user();
        $roleID = $user->role->first()->role_id;
        $role = Role::find($roleID);
        return $role;
    }



}
