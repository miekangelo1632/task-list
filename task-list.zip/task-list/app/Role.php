<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    protected $fillable = ['description'];

    public function userList() {
        return $this->belongsToMany('App\User', 'user_roles', 'role_id', 'user_id');
    }

    public function roleDescription() {
        return $this->description;
    }
}
