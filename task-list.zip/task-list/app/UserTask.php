<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserTask extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'task',
        'done',
    ];

    public function user() {
        return $this->belongsTo('App\User');
    }
}
