<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\User;
use App\Role;
use App\UserRole;
use App\UserTask;

use Validator;
use Auth;

class UserController extends Controller
{

    public function show() {
        $roles = Role::all()->pluck('description', 'id')->toArray();

        return view('auth.register', compact('roles'));
    }

    public function register(Request $request) {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|max:255',
            'last_name' => 'required|max:255',
            'username' => 'required|min:6|max:255|unique:users',
            'role' => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->username = $request->username;
        $user->password = bcrypt($request['password']);
        $user->save();

        $userRole = new UserRole();
        $userRole->role_id = $request->role;

        $user->role()->save($userRole);

        return redirect('/login')->with('status', 'Registration Complete!');
    }

    public function showUsers() {
        $users = User::with('role')->where('id', '!=', 1)->get();

        return view('admin.userList', compact('users'));
    }

    public function showProfile() {
        $id = Auth::user()->id;
        $user = User::find($id);

        $tasks = $user->tasks;

        return view('user.profileIndex', compact('tasks'));
    }

}
