<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;
use App\Role;
use App\UserRole;
use App\UserTask;

use App\Http\Requests;
use Validator;
use Carbon\Carbon;
use DB;

class UserTaskController extends Controller
{
    public function userTasks(Request $request, $id) {
        $user = User::findOrFail($id);

        $tasks = $user->tasks;

        return view('admin.userTasks', compact('tasks', 'user'));
    }

    public function addTask(Request $request, $id) {
        $validator = Validator::make($request->all(), [
            'description' => 'required|min:4|max:255',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $user = User::findOrFail($id);

        $task = new UserTask();
        $task->task = $request->description;
        $user->tasks()->save($task);

        return back()
            ->with('status', 'Task Added!')
            ;
    }

    public function deleteTask($id, $tid) {
        $deleteTask = UserTask::destroy($tid);

        return back()
            ->with('deleted', 'Task Deleted!')
            ;
    }

    public function showAllTasks() {
        $tasks = UserTask::with('user')->get();

        return view('admin.taskList', compact('tasks'));
    }

    public function  showPendingTasks(Request $request) {
        $validator = Validator::make($request->all(), [
            'username' => 'required',
            '_date' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $dateNow = Carbon::parse('now');
        $min = Carbon::parse('now')->subWeek();
        $username = $request->username;

        if($request->_date == "LW") {
            $tasks = DB::table('users')
                ->join('user_tasks', 'users.id', '=', 'user_tasks.user_id')
                ->where('users.username', 'like', '%'.$username.'%')
                ->where('user_tasks.done', '=', 0)
                ->where('user_tasks.created_at', '>=', $min)
                ->where('user_tasks.created_at', '<=', $dateNow)
                ->select('users.username', 'user_tasks.task', 'user_tasks.done', 'user_tasks.created_at')
                ->get();
        }
        else {
            $tasks = DB::table('users')
                ->join('user_tasks', 'users.id', '=', 'user_tasks.user_id')
                ->where('users.username', 'like', '%'.$username.'%')
                ->where('user_tasks.done', '=', 0)
                ->select('users.username', 'user_tasks.task', 'user_tasks.done', 'user_tasks.created_at')
                ->get();
        }

        return view('admin.generatePendingTask', compact('tasks'));
    }

    public function markAsDone($id) {
        $task = UserTask::findOrFail($id);

        $task->done = 1;
        $task->save();

        return redirect()->back()
            ->with('status', 'Updated');
    }

}
