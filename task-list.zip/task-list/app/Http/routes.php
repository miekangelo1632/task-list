<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return redirect('/home');
});

Route::get('/test', function () {
    $user = Auth::user();
    return $user->roleDescription();
});

Route::get('/home', 'HomeController@index');

Route::get('/register', 'UserController@show');
Route::post('/register', 'UserController@register');

Route::get('/login', 'Auth\AuthController@showLoginForm');
Route::post('/login', 'Auth\AuthController@login');
Route::get('/logout', 'Auth\AuthController@logout');

//admin routes
Route::group(['middleware' => ['adminOnly']], function () {
    Route::get('/user-list', 'UserController@showUsers');

    Route::get('/user-list/{id}/tasks', 'UserTaskController@userTasks');
    Route::post('/user-list/{id}/addTask', 'UserTaskController@addTask');
    Route::post('/user-list/{id}/deleteTask/{tid}', 'UserTaskController@deleteTask');

    Route::get('/task-list', 'UserTaskController@showAllTasks');
    Route::get('/task-list/pending', 'UserTaskController@showPendingTasks');
});

//user route list
Route::group(['middleware' => ['userOnly']], function () {
    Route::get('/profile', 'UserController@showProfile');
    Route::get('/profile/task/{id}', 'UserTaskController@markAsDone');
});


