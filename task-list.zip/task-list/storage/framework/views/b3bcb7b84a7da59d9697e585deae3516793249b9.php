<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session()->has('status')): ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> <?php echo e(session()->get('status')); ?></h4>
                    </div>
                </div>
            </div><!-- alert -->
        <?php endif; ?>

        <?php if(session()->has('deleted')): ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-warning alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> <?php echo e(session()->get('deleted')); ?></h4>
                    </div>
                </div>
            </div><!-- alert -->
        <?php endif; ?>

        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading col-xs-12">
                        <?php echo e($user->username); ?>

                    </div>

                    <div class="panel-body table-responsive">
                        <form action="<?php echo e(action('UserTaskController@addTask', $user->id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-offset-6 input-group margin<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                                <input type="text" name="description" class="form-control" id="taskDescription">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-info btn-flat">Add Task</button>
                                </span>
                            </div>
                            <?php if($errors->has('description')): ?>
                                <span class="help-block pull-right" style="color: #991509">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </form><!-- add task form -->

                        <table class="table table-bordered" id="userTable">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($tasks as $task): ?>
                                    <tr>
                                        <td><?php echo e($task->task); ?></td>
                                        <td>
                                            <?php if($task->done === 0): ?>
                                                Pending
                                            <?php else: ?>
                                                Done
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($task->created_at); ?></td>
                                        <td>
                                            <form action="<?php echo e(action('UserTaskController@deleteTask', [$user->id, $task->id])); ?>" method="POST" onclick="return confirm('Are you sure you want to delete this item?');">
                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-xs btn-block btn-danger">
                                                    <i class=" fa fa-trash"> <span class="hidden-xs"> Delete</span></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>

                        </table><!-- user tasks table -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            $('#userTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "order": [[ 1, "desc" ]],
                "info": true,
                "autoWidth": false,
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>