<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(session()->has('status')): ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> <?php echo e(session()->get('status')); ?></h4>
                    </div>
                </div>
            </div><!-- alert -->
        <?php endif; ?>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Your Task</div>

                    <div class="panel-body table-responsive">
                        <table class="table table-bordered" id="userTable">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($tasks as $task): ?>
                                    <tr>
                                        <td><?php echo e($task->task); ?></td>
                                        <td>
                                            <?php if($task->done == 0): ?>
                                                Pending
                                            <?php else: ?>
                                                Done
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($task->created_at); ?></td>
                                        <td>
                                            <?php if($task->done == 0): ?>
                                                <a href="<?php echo e(action('UserTaskController@markAsDone', $task->id)); ?>">Mark as Done</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            $('#userTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>