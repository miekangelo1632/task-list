@extends('layouts.app')

@section('content')
    <div class="container">
        @if(session()->has('status'))
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> {{ session()->get('status') }}</h4>
                    </div>
                </div>
            </div><!-- alert -->
        @endif
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Your Task</div>

                    <div class="panel-body table-responsive">
                        <table class="table table-bordered" id="userTable">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($tasks as $task)
                                    <tr>
                                        <td>{{ $task->task }}</td>
                                        <td>
                                            @if($task->done == 0)
                                                Pending
                                            @else
                                                Done
                                            @endif
                                        </td>
                                        <td>{{ $task->created_at }}</td>
                                        <td>
                                            @if($task->done == 0)
                                                <a href="{{ action('UserTaskController@markAsDone', $task->id) }}">Mark as Done</a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(function () {
            $('#userTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
@endsection

