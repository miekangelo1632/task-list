@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Pending Tasks</div>

                    <div class="panel-body table-responsive">
                        <table class="table table-bordered" id="taskTable">
                            <br>
                            <thead>
                            <tr>
                                <th>Username</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Date Created</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($tasks as $task)
                                <tr>
                                    <td>{{ $task->username }}</td>
                                    <td>{{ $task->task }}</td>
                                    <td>
                                        @if($task->done == 0)
                                            Pending
                                        @else
                                            Done
                                        @endif
                                    </td>
                                    <td>{{ $task->created_at }}</td>
                                </tr>
                            @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        $(function () {
            var table = $('#taskTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

    </script>
@endsection

