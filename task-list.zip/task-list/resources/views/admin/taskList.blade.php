@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Search Pending</div>

                    <div class="panel-body table-responsive">
                        <form action="{{ action('UserTaskController@showPendingTasks') }}" class="form-horizontal">
                            @if ($errors->has('username'))
                                <span class="help-block" style="color: #8f0000">
                                        <strong>The Username field is required</strong>
                                    </span>
                            @endif
                            <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
                                <label for="username" class="col-md-3 control-label">Username</label>
                                <div class="col-md-7">
                                    <input id="username" type="text" class="form-control" name="username">
                                </div>
                            </div>

                            @if ($errors->has('_date'))
                                <span class="help-block" style="color: #8f0000">
                                        <strong>The Option field is required</strong>
                                    </span>
                            @endif
                            <div class="form-group{{ $errors->has('_date') ? ' has-error' : '' }}">
                                <label for="date" class="col-md-3 control-label">Option</label>
                                <span>
                                    <div class="radio col-md-7">
                                        <label>
                                            <input type="radio" name="_date" id="date" value="ALL">
                                            All
                                        </label>
                                        <span>&nbsp;</span>
                                        <span>&nbsp;</span>
                                        <span>&nbsp;</span>
                                        <span>
                                            <label>
                                                <input type="radio" name="_date" id="date" value="LW">
                                                Last Week
                                            </label>
                                        </span>
                                    </div>
                                </span>
                            </div>

                            <div class="form-group">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-user"></i>
                                        Search
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Task List</div>

                    <div class="panel-body table-responsive">
                        <table class="table table-bordered" id="taskTable">
                            <br>
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($tasks as $task)
                                    <tr>
                                        <td>{{ $task->user->username }}</td>
                                        <td>{{ $task->task }}</td>
                                        <td>
                                            @if($task->done == 0)
                                                Pending
                                            @else
                                                Done
                                            @endif
                                        </td>
                                        <td>{{ $task->created_at }}</td>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        $(function () {
            var table = $('#taskTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
            });
        });

    </script>
@endsection

