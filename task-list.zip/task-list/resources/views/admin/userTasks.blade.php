@extends('layouts.app')

@section('content')
    <div class="container">
        @if(session()->has('status'))
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> {{ session()->get('status') }}</h4>
                    </div>
                </div>
            </div><!-- alert -->
        @endif

        @if(session()->has('deleted'))
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="alert alert-warning alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> {{ session()->get('deleted') }}</h4>
                    </div>
                </div>
            </div><!-- alert -->
        @endif

        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading col-xs-12">
                        {{ $user->username }}
                    </div>

                    <div class="panel-body table-responsive">
                        <form action="{{ action('UserTaskController@addTask', $user->id) }}" method="POST">
                            {{ csrf_field() }}
                            <div class="col-md-offset-6 input-group margin{{ $errors->has('description') ? ' has-error' : '' }}">
                                <input type="text" name="description" class="form-control" id="taskDescription">
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-info btn-flat">Add Task</button>
                                </span>
                            </div>
                            @if ($errors->has('description'))
                                <span class="help-block pull-right" style="color: #991509">
                                    <strong>{{ $errors->first('description') }}</strong>
                                </span>
                            @endif
                        </form><!-- add task form -->

                        <table class="table table-bordered" id="userTable">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Date Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($tasks as $task)
                                    <tr>
                                        <td>{{ $task->task }}</td>
                                        <td>
                                            @if($task->done === 0)
                                                Pending
                                            @else
                                                Done
                                            @endif
                                        </td>
                                        <td>{{ $task->created_at }}</td>
                                        <td>
                                            <form action="{{ action('UserTaskController@deleteTask', [$user->id, $task->id]) }}" method="POST" onclick="return confirm('Are you sure you want to delete this item?');">
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-xs btn-block btn-danger">
                                                    <i class=" fa fa-trash"> <span class="hidden-xs"> Delete</span></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>

                        </table><!-- user tasks table -->
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(function () {
            $('#userTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "order": [[ 1, "desc" ]],
                "info": true,
                "autoWidth": false,
            });
        });
    </script>
@endsection

