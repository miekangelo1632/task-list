<?php

use Illuminate\Database\Seeder;

use App\Role;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = new Role();
        $role->description = "Admin";
        $role->save();

        $role = new Role();
        $role->description = "Software Engineer";
        $role->save();

        $role = new Role();
        $role->description = "Systems Analyst";
        $role->save();

        $role = new Role();
        $role->description = "Technical Support";
        $role->save();

        $role = new Role();
        $role->description = "Network Engineer";
        $role->save();

        $role = new Role();
        $role->description = "Technical Consultant";
        $role->save();

        $role = new Role();
        $role->description = "Technical Sales";
        $role->save();

        $role = new Role();
        $role->description = "Web Developer";
        $role->save();

        $role = new Role();
        $role->description = "Software Tester";
        $role->save();
    }
}
